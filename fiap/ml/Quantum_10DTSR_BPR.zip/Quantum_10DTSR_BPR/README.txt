Abaixo, o link do Colab com o codigo executado, caso demore ou não esteja executando o jupyter notebook:

https://colab.research.google.com/drive/1bgUwQjhK4a77V82ba3GKJcjZNl0Oin0q?usp=sharing

