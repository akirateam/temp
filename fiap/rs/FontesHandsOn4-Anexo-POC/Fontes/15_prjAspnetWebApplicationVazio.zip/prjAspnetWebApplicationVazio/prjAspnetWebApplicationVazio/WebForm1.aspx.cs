﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace prjAspnetWebApplicationVazio
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        Dados objDados = new Dados();

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsPostBack == false)
                {
                    //dropdown cliente
                    DataTable dt = objDados.listarClientes();
                    DropDownList1.DataSource = dt;
                    DropDownList1.DataTextField = "nomeCliente";
                    DropDownList1.DataBind();
                    //usuário mais similar
                    string strClienteMaisSimilar = objDados.consultarClienteMaisSimilar(DropDownList1.Text);
                    //gridview recomendacao
                    dt = objDados.listarRecomendacaoOF(DropDownList1.Text, strClienteMaisSimilar);
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                    //gridview popularidade
                    dt = objDados.listarProdutosPopularidade();
                    GridView2.DataSource = dt;
                    GridView2.DataBind();
                    
                }
            }
            catch (Exception ex)
            {
                lblResultado.Text = ex.Message;
            }
        }
        protected void btnAtualizarCliente_Click(object sender, EventArgs e)
        {
            //gridview recomendacao
            string strClienteMaisSimilar = objDados.consultarClienteMaisSimilar(DropDownList1.Text);
            //gridview recomendacao
            DataTable dt = objDados.listarRecomendacaoOF(DropDownList1.Text, strClienteMaisSimilar);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            //gridview popularidade
            dt = objDados.listarProdutosPopularidade();
            GridView2.DataSource = dt;
            GridView2.DataBind();
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            try
            {

                if (ImageButton1.ImageUrl == "~/likeNao.png")
                {
                    ImageButton1.ImageUrl = "~/likeSim.png";
                    objDados.IncrementarLike("Cartão de Crédito");
                }
                else
                {
                    ImageButton1.ImageUrl = "~/likeNao.png";
                    objDados.DecrementarLike("Cartão de Crédito");
                }
            }

            catch (Exception ex)
            {
                lblResultado.Text = ex.Message;
            }

        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                if (ImageButton2.ImageUrl == "~/likeNao.png")
                {
                    ImageButton2.ImageUrl = "~/likeSim.png";
                    objDados.IncrementarLike("Conta Corrente");
                }
                else
                {
                    ImageButton2.ImageUrl = "~/likeNao.png";
                    objDados.DecrementarLike("Conta Corrente");
                }
            }
            catch(Exception ex)
            {
                lblResultado.Text = ex.Message;
            }
        }

        protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
        {
            if (ImageButton3.ImageUrl == "~/likeNao.png")
            {
                ImageButton3.ImageUrl = "~/likeSim.png";
                objDados.IncrementarLike("Crédito Pessoal");
            }
            else
            {
                ImageButton3.ImageUrl = "~/likeNao.png";
                objDados.DecrementarLike("Crédito Pessoal");
            }
        }

        protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
        {
            if (ImageButton4.ImageUrl == "~/likeNao.png")
            {
                ImageButton4.ImageUrl = "~/likeSim.png";
                objDados.IncrementarLike("Poupança");

            }
            else
            {
                ImageButton4.ImageUrl = "~/likeNao.png";
                objDados.DecrementarLike("Poupança");
            }

        }

        protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
        {
            if (ImageButton5.ImageUrl == "~/likeNao.png")
            {
                ImageButton5.ImageUrl = "~/likeSim.png";
                objDados.IncrementarLike("Renda Fixa");

            }
            else
            {
                ImageButton5.ImageUrl = "~/likeNao.png";
                objDados.DecrementarLike("Renda Fixa");
            }

        }

        protected void ImageButton6_Click(object sender, ImageClickEventArgs e)
        {
            if (ImageButton6.ImageUrl == "~/likeNao.png")
            {
                ImageButton6.ImageUrl = "~/likeSim.png";
                objDados.IncrementarLike("Renda Variável");

            }
            else
            {
                ImageButton6.ImageUrl = "~/likeNao.png";
                objDados.DecrementarLike("Renda Variável");
            }

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}